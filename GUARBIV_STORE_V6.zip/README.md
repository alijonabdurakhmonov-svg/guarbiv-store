# GUARBIV STORE V6 — FOUNDATION

Included:
- Responsive storefront
- RU/EN switch
- Product cards and details
- Local cart
- Prototype account/profile
- Newsletter prototype
- Local GUARBIV Assistant

Production backend still needed for real authentication, database, inventory, orders, payments, shipping and AI API.
